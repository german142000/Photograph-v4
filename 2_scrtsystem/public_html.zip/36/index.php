<?php
$pass = 'qwerty15';
?>
<?php


header('content-Type: text/html; charset=utf-8');


error_reporting(E_ALL);

if (stream_resolve_include_path('config.php')) {
    include_once ('config.php');
	} else {
		die ("Not found file: config.php");
	}

if (stream_resolve_include_path('language/'.$config["language"].'.lng') )
{
	require_once 'language/'.$config["language"].'.lng';
}
else {
	require_once 'language/en.lng';
	echo 'Not found language/'.$config["language"].'.lng';

}
define ('ROOT', $config["rootdirectory"].'/' );

//............. tree .........................................
	function tree($path)
	{
    if( stream_resolve_include_path($path)) {
	
	$files = scandir($path);
	
	natcasesort($files);
	
    $files2 = array();
	
    echo '<ul>';
	
	if( count($files) > 2 ) {
		
		
		foreach( $files as $file ) {
			
			if(stream_resolve_include_path($path . $file) && $file != '.' && $file != '..') {
				
			 
			if  (filetype($path.$file)=='dir') {
			// if folder
			sub($file, $path);
			}else {
			//if files
					$files2[$file] = $file;
					
				}
		}
		}
//	}
					foreach ($files2 as $file) {
					
				if($file) {
				
        $ext = strtolower(preg_replace('/^.*\./', '', $file));			
		echo '<li class="ext-file ext-'.$ext.'">'.$file.'</li>';
		       }
		       } 
}
		echo "</ul>";	
	

}
}

	function sub($dir, $path)
	{
		echo '<li><div id="'.$dir.'" data-fo="'.$path.$dir.'/'.'" class="fo closed">'.$dir.'</div>';
		tree($path.$dir.'/');
		echo '</li>';
	}
//................. end tree ...................................
 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>Менеджер файлов</title>	
    <meta name="description" content="Simple file manager, file browser with file upload, editor with syntax highlighting. Простой файловый менеджер, файловый браузер с загрузкой файлов, редактор с подсветкой синтаксиса" /> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" type="text/css" href="panel.css">
    <link rel="stylesheet" href="font-awesome.min.css">
</head>

<body style="background-image: url(glBack.jpg);">
<div id="page-preloader"><span id="spinner">Loading ...</span>

<form method='get' action=''>
	
	<input name='pass' style='z-index:999999999999999;' type='text'>

	</form>

</div>
<div class="ab-container ab-filemanager" id="ab-main">

<div id="ab-conten" class="ab-r">

<!-- breadcrumb -->	        	
	<div class="ab-col12" id="ab-breadcrumb">
<div id="breadcrumb-links" class="ab-col7">
<span class="open"><?php echo ROOT ?> </span>

	</div>
	    <div id="ab-top-action-btn" class="ab-col5 ab-text-right">
	<a id="a-create-folder" class="ab-btn asphalt" title="<?php echo $lang['create_folder_here'] ?>" href="#"><i class="fa fa-folder-o" aria-hidden="true"></i> </a>

	  <button id="createfile" class="ab-btn asphalt" title="<?php echo $lang['create_file_here'] ?>"><i class="fa fa-file-text-o" aria-hidden="true"></i></button>

	<div id="div-uploadfile" class="ab-btn asphalt fa fa-upload" title="<?php echo $lang['upload_file_here'] ?>">
				<form id="frm-uploadfile" name="frm-uploadfile" enctype="multipart/form-data">	
					<input type="file" id="file" name="file[]" multiple="multiple">
					<input type="hidden" id="inputpath" name="inputpath">
				</form>
	</div>

<a id="zipsite" class="ab-btn asphalt" title="<?php echo $lang['zip_and_download_site'] ?>"  href="downloadfolder.php?file=<?php echo ROOT ?>"><i class=" fa fa-download" aria-hidden="true"></i></a>	
<a class="ab-btn asphalt" title="<?php echo $lang['general_settings'] ?>"  href="editor.php?editfile=config.php" target="_blank"><i class=" fa fa-cog" aria-hidden="true"></i></a>		  
	  
		
 <link rel="stylesheet" href="cmd.css">
  <script src="cmd.js"></script>

     <a id="callback-button" class="ab-btn asphalt"><img src="images/cmd.png" width="100%" alt=""></a>
 
	
		
	</div>
	</div>

<!-- left panel ........................................... -->




 </div>
  <div class="modal" id="modal-1">
    <div class="modal__content">
      <button class="modal__close-button"><img src="./img/close.svg" width="12" alt=""></button>
	
<?php include('cmd.php'); ?>
	
    </div>
  </div>











<input type="checkbox" id="side-checkbox">
<div class="side-panel dfg">
<style>
.dfg{
overflow-x: scroll;
overflow-y: scroll;
-ms-overflow-style: none;  /* IE и Edge */
scrollbar-width: none;
}
.dfg::-webkit-scrollbar {
  display: none;
}

</style>
    <label class="side-button-2" for="side-checkbox">+</label>
    
<div class="side-title">Древо директорий:</div><p id="bmenu"></p>

 <div id="leftpane" class="pass">
<div id="tree">

<div id="home" data-fo="<?php echo ROOT  ?>" class="closed selected">
<?php echo basename(ROOT)  ?>
</div>
<!-- tree  -->
<?php tree(ROOT); ?>

</div>
</div>	

</div>

<div class="side-button-1-wr">
    
    <label class="side-button-1" for="side-checkbox">
        
        <div class="side-b side-open">=</div>
        
        <div class="side-b side-close">=</div>
    
    </label></div>

<!-- table data ........................................... -->

<div class="ab-col8" id="ab-container-table">
    <!-- ajax data here.. -->
</div>

</div>



    </div>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.3/jquery.min.js"></script>
	<script>
	if (typeof jQuery == 'undefined') {
	  document.write(unescape("%3Cscript src='jquery.js' type='text/javascript'%3E%3C/script%3E"));
	}</script>
	<script src="script.js"></script>

<script>
	$(document).ready(function($)
    {
	
//showtable

	
	<?php

	if ($_GET['pass'] == $pass){
	
echo "function showtable(folder) {

	$.post('showtable.php', { dir: folder}, function(data) {
						
	$('#ab-container-table').html('').append(data);

	});
	}";}
	?>
	
	showtable('<?php echo ROOT  ?>');
	
	//.................. loader, start page ....................	
    var $preloader = document.getElementById("page-preloader"),
        $spinner   = document.getElementById("spinner");
        $spinner.className += " hidden";
        $preloader.className += " hidden";

	});
	</script>
	
</body>
</html>
