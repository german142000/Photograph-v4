<?php
$config = array

(

  'rootdirectory'         => $_SERVER['DOCUMENT_ROOT'],    

  'language'              => 'ru',                          

  'extensions_for_editor' => array('ab','txt','php','js','tpl',
								   'html','htm','css','text','json','lng','xml','ini','sql','txt', 'py', 'htaccess',
								   'scrt', 'csm') 

);