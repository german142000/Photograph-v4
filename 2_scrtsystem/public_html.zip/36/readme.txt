To set/change a password: index.php=>"$pass = 'your password'"



To clear the session in the terminal, use the command: "?cls>"